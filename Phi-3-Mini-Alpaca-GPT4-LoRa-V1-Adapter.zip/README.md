# Training Report - Kaggle 2x T4

## Model: microsoft/Phi-3-mini-4k-instruct

## Results
- Final Training Loss: 0.9263
- Final Eval Loss: 0.9130
- Training Time: 11:50:35
- Total Steps: 5850
- Epochs: 1
- Hardware: Kaggle 2x T4 GPU

## Usage

```python
from transformers import AutoModelForCausalLM, AutoTokenizer
from peft import PeftModel
import torch

base_model = AutoModelForCausalLM.from_pretrained(
    "microsoft/Phi-3-mini-4k-instruct",
    device_map="auto",
    torch_dtype=torch.float16
)

model = PeftModel.from_pretrained(base_model, "path/to/model")
tokenizer = AutoTokenizer.from_pretrained("path/to/model")

prompt = "Your instruction here"
inputs = tokenizer(prompt, return_tensors="pt").to("cuda")
outputs = model.generate(**inputs, max_length=200)
print(tokenizer.decode(outputs[0], skip_special_tokens=True))
```
